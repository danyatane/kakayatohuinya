﻿namespace lab8
{
    // Наследуем от абстрактного класс Samsung
    public class Samsung : Phone
    {
        // Указываем значения полей
        public override string name => "Samsung Galaxy S24";
        public override string color => "Черный оникс";
        public override string systemVersion => "OneUI 6.0";

        // Определяем методы
        public override string OpenCamera()
        {
            return "Приложение 'Камера' открывается быстро";
        }
        public override string DownloadApp()
        {
            return "открывается Google PlayMarket";
        }
    }
}