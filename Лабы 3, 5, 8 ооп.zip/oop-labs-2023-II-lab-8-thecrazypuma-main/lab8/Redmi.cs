﻿namespace lab8
{
    // Наследуем от абстрактного класс Redmi
    public class Redmi : Phone
    {
        // Указываем значения полей
        public override string name => "Note 13";
        public override string color => "Мятный зеленый";
        public override string systemVersion => "Android 13";

        // Определяем методы
        public override string OpenCamera()
        {
            return "Приложение 'Камера' открывается";
        }
        public override string DownloadApp()
        {
            return "открывается RuStore";
        }
    }
}