﻿namespace lab8
{
    // Абстрактный класс Phone, от которого наследуются другие классы телефонов
    public abstract class Phone
    {
        // Содежит поля и методы, которые определяются в классах телефонов
        public abstract string name { get; }
        public abstract string color { get; }
        public abstract string systemVersion { get; }
        public abstract string OpenCamera();
        public abstract string DownloadApp();

    }
}