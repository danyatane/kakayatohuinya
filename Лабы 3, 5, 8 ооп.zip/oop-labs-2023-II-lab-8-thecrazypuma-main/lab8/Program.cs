﻿using System;

namespace lab8
{
    internal class Program
    {
        static void Main(string[] args)
        {
            // создаем список телефонов и добавляем в него телефоны различных моделей
            List<Phone> phones = new List<Phone>();
            phones.Add(new IPhone());
            phones.Add(new Redmi());
            phones.Add(new Samsung());

            // Выводим информацию о всех телефонах в консоль
            foreach (Phone phone in phones)
            {
                GetInfo(phone);
            }

        }

        // метод для вывода информации о телефоне
        static public void GetInfo(Phone phone1)
        {
            Console.WriteLine("Название телефона: " + phone1.name +
                "\nЦвет: " + phone1.color +
                "\nСистема: - " + phone1.systemVersion +
                "\n" + phone1.OpenCamera() +
                "\nНеобходимо скачать приложение: " + phone1.DownloadApp() + "\n");
        }
    }
}