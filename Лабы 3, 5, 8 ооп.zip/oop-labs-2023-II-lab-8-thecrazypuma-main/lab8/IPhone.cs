﻿namespace lab8
{
    // Наследуем от абстрактного класс IPhone
    public class IPhone : Phone
    {
        // Указываем значения полей
        public override string name => "iPhone 15";
        public override string color => "Черный титан";
        public override string systemVersion => "IOS 15.2";

        // Определяем методы
        public override string OpenCamera()
        {
            return "Приложение 'Камера' быстро открывается";
        }
        public override string DownloadApp()
        {
            return "открывается AppStore";
        }
    }
}