﻿using lab5;

// То же самое, что и в 3 лабе
namespace DataAccess
{
    public class StudentsRepository
    {
        private string fileName;

        public string Filename
        {
            get { return fileName; }
            set { fileName = value; }
        }

        public StudentsRepository(string fileName)
        {
            Filename = fileName;
        }

        public void readStudentsInfo()
        {
            StreamReader streamReader = new StreamReader(Filename);
            string line = streamReader.ReadLine();
            while (line != null)
            {
                Console.WriteLine(line);
                line = streamReader.ReadLine();
            }
            streamReader.Close();
        }

        public void writeStudentsInfo(University university)
        {
            string result = "";
            foreach (Student student in university.Students)
            {
                result += $"[index = {university.Students.IndexOf(student)}] {student.Name} {student.Surname}, возраст: {student.Age}, средний балл: {student.averageScore}\n";
            }
            StreamWriter streamWriter = new StreamWriter(Filename);
            streamWriter.WriteLine(result);
            streamWriter.Close();
        }
    }
}

namespace lab5
{
    public class Person
    {
        // поля для вычисления и присвоения уникального номера
        private static int count = 0;
        protected int personalNumber;

        // публичный метод для получения уникального номера
        public int PersonalNumber
        {
            get { return personalNumber; }
        }

        // поля для данных (за исключением среднего балла) теперь относятся к этому классу
        protected string name;
        protected string surname;
        protected int age;

        // конструктор класса, сохраняет данные, введенные при создании объекта, и вычисляет уникальный номер
        public Person(string name, string surname, int age)
        {
            Name = name;
            Surname = surname;
            Age = age;

            // вычисляем уникальный номер
            count++;
            personalNumber = count;

            // добавляем человека в базу всех людей
            PeopleData.AddPerson(this);
        }

        // публичные методы, не отличаются от 3 лабы
        public string Name
        {
            get { return name; }
            set { name = value; }
        }

        public string Surname
        {
            get { return surname; }
            set { surname = value; }
        }

        public int Age
        {
            get { return age; }
            set { age = value; }
        }
    }

    // Класс Student, наследуется от класса Person
    public class Student : Person
    {
        // в качестве полей объявляем только средний балл, остальное наследуется от Student
        public double averageScore;

        // конструктор класса, записывает данные о студенте в поля
        public Student(string name, string surname, int age, double averageScore) : base(name, surname, age)
        {
            AverageGrade = averageScore;
        }

       // публичные методы для получения/изменения данных о среднем балле и номере зачетной книжки
        public double AverageGrade
        {
            get { return averageScore; }
            set { averageScore = value; }
        }
        public int StudentBookNumber { get; set; }
    }

    // класс University для работы со списком студентов
    public class University
    {
        private List<Student> students;
        // добавили поле номер зачетной книжки
        private int studentBookNumber;

        // конструктор класса
        public University()
        {
            students = new List<Student>();
            // начальный номер для зачетной книжки устанавливаем 1000
            studentBookNumber = 1000;
        }

        // Публичный метод для получения списка студентов
        public List<Student> Students
        {
            get { return students; }
            set { students = value; }
        }

        // Добавление студента
        public void AddStudent(Student student)
        {
            // каждому студенту номер зачетной книжки делаем на 1 больше предыдущего
            student.StudentBookNumber = studentBookNumber++;
            students.Add(student);
        }

        // Удаление студента
        public void DeleteStudent(Student student)
        {
            students.Remove(student);
        }

        // метод для поиска студента по уникальному номеру человека
        public Student FindStudentByPersonalNumber(int personalNumber)
        {
            foreach (Student student in students)
            {
                if (student.PersonalNumber == personalNumber)
                {
                    return student;
                }
            }
            throw new Exception("Студент не найден");
        }

        // метод для поиска студента по номеру зачетной книжки
        public Student FindStudentByStudentBookNumber(int studentBookNumber)
        {
            foreach (Student student in students)
            {
                if (student.StudentBookNumber == studentBookNumber)
                {
                    return student;
                }
            }
            throw new Exception("Студент не найден");
        }
    }

    // класс PeopleData для хранения данных всех людей
    public static class PeopleData
    {
        // приватное поле списка для хранения данных
        private static List<Person> people = new List<Person>();

        // публичный метод добавления человека
        public static void AddPerson(Person person)
        {
            people.Add(person);
        }

        // поиск человека по уникальному номеру
        public static Person GetPersonByPersonalNumber(int personalNumber)
        {
            foreach (Person person in people)
            {
                if (person.PersonalNumber == personalNumber)
                {
                    return person;
                }
            }
            throw new Exception("Человек не найден");
        }
    }

    // основной класс программы
    class lab5
    {
        static void Main(string[] args)
        {
            // тестируем программу, создаем тестовые объекты
            University Polytech = new University();
            Student student1 = new Student("Ivan", "Ivanov", 20, 4.7);
            Student student2 = new Student("Petr", "Petrov", 21, 3.9);
            Person person1 = new Person("Gleb", "Smirnov", 22);
            Person person2 = new Person("Andrei", "Sidorov", 23);

            // добавляем студентов в университет
            Polytech.AddStudent(student1);
            Polytech.AddStudent(student2);

            // Вывод номера зачетки добавленных студентов
            Console.WriteLine("Номер зачетки первого студента: " + student1.StudentBookNumber);
            Console.WriteLine("Номер зачетки второго студента: " + student2.StudentBookNumber);
            Console.WriteLine("\n");


            // Вывод информации о студентах по номеру их зачетки

            // Находим студента
            Student find = Polytech.FindStudentByStudentBookNumber(1000);
            // и выводим информацию о нем в консоль
            Console.WriteLine("Номер зачетки: " + find.StudentBookNumber + ". Студент: " + find.Name + " " +
                find.Surname + ", средний балл: " + find.AverageGrade + ", возраст: " + find.Age);

            // то же самое для второго студента
            find = Polytech.FindStudentByStudentBookNumber(1001);
            Console.WriteLine("Номер зачетки: " + find.StudentBookNumber + ". Студент: " + find.Name + " " + 
                find.Surname + ", средний балл: " + find.AverageGrade + ", возраст: " + find.Age);

            Console.WriteLine("\n");


            // Вывод информации о студентах по уникальному номеру
            find = Polytech.FindStudentByPersonalNumber(1);
            Console.WriteLine("Студента с id = " + find.PersonalNumber + " зовут: " + find.Name + " " + 
                find.Surname + " и он имеет средний балл: " + find.AverageGrade);

            find = Polytech.FindStudentByPersonalNumber(2);
            Console.WriteLine("Студента с id = " + find.PersonalNumber + " зовут: " + find.Name + " " +
                find.Surname + " и он имеет средний балл: " + find.AverageGrade);

            Console.WriteLine("\n");


            // Вывод информации о человеке по его уникальному номеру
            Person people = PeopleData.GetPersonByPersonalNumber(1);
            Console.WriteLine("Человека с id = " + people.PersonalNumber + " зовут: " +
                people.Name + " " + people.Surname + " и ему " + people.Age + " лет.");

            people = PeopleData.GetPersonByPersonalNumber(2);
            Console.WriteLine("Человека с id = " + people.PersonalNumber + " зовут: " +
                people.Name + " " + people.Surname + " и ему " + people.Age + " лет.");

            people = PeopleData.GetPersonByPersonalNumber(3);
            Console.WriteLine("Человека с id = " + people.PersonalNumber + " зовут: " +
                people.Name + " " + people.Surname + " и ему " + people.Age + " лет.");

            people = PeopleData.GetPersonByPersonalNumber(4);
            Console.WriteLine("Человека с id = " + people.PersonalNumber + " зовут: " +
                people.Name + " " + people.Surname + " и ему " + people.Age + " лет.");

            Console.WriteLine("\n");
        }
    }
}