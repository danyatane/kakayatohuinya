﻿using lab3;

namespace lab3
{
    // Класс Student, содержит поля с информацией о студенте и методы для получения этой информации
    public class Student
    {
        // Приватные поля для хранения данных о студенте
        private string name;
        private string surname;
        private int age;
        private double averageScore;

        // Конструктор класса, при создании объекта записывает данные в приватные поля
        public Student(string name, string surname, int age, double avgScore)
        {
            Name = name;
            Surname = surname;
            Age = age;
            AverageScore = avgScore;
        }

        // Публичные методы для получения информации о студенте
        // Так как поля приватные, получить информацию возможно только через эти методы
        public string Name
        {
            get { return name; }
            set { name = value; }
        }

        public string Surname
        {
            get { return surname; }
            set { surname = value; }
        }

        public int Age
        {
            get { return age; }
            set { age = value; }
        }

        public double AverageScore
        {
            get { return averageScore; }
            set { averageScore = value; }
        }
    }

    //Класс University, содержит список студентов (массив объектов класса Student) и методы для работы с ним
    public class University
    {
        // Приваитное поле для хранения списка студентов
        private List<Student> students;

        // Публичный метод для получения списка студентов
        // Необходим для доступа к полю извне класса, так как поле приватное
        public List<Student> Students
        {
            get { return students; }
            set { students = value; }
        }

        // Конструктор класса, записывает список студентов в поле при создании объекта класса
        public University(List<Student> students)
        {
            Students = students;
        }

        // Далее идут публичные методы для работы со списком

        // Добавление студента в список
        public void AddStudent(Student student)
        {
            students.Add(student);
        }

        // Удаление студента из списка
        public void RemoveStudent(Student student)
        {
            students.Remove(student);
        }

        // Поиск студента по имени и фамилии
        public void FindStudent(string name, string surname)
        {
            bool found = false;
            // Создаем список с результатами поиска
            List<Student> searchResults = new List<Student>();

            // Проходим по всем студентам, подходящих добавляем в список
            foreach (Student student in students)
            {
                if (student.Name == name && student.Surname == surname)
                {
                    found = true;
                    searchResults.Add(student);
                }
            }

            // Выводим всех найденных студентов в консоль
            if (found)
            {
                foreach (Student student in searchResults)
                {
                    Console.WriteLine($"{student.Name} {student.Surname}");
                }
            }
            else { Console.WriteLine("Ничего не найдено :((("); }
        }
    }
}

// Отдельное пространство имен для работы с базой студентов
namespace DataAccess
{
    // Класс для работы с файлом базы студентов, содержит поле для названия файла и методы для работы с файлом
    public class StudentsRepository
    {
        // Приватное поле, хранящее имя файла
        private string fileName;

        // Конструктор класса, при создании объекта записывает имя файла в приватное поле
        public StudentsRepository(string fileName)
        {
            Filename = fileName;
        }

        // Публичный метод для получения имени файла
        public string Filename
        {
            get { return fileName; }
            set { fileName = value; }
        }

        // Метод для чтения файла с данными о студентах
        public void readStudentsInfo()
        {
            // Создание потока
            StreamReader streamReader = new StreamReader(Filename);
            string line = streamReader.ReadLine();

            // Построчное считывание информации из файла
            while (line != null)
            {
                Console.WriteLine(line);
                line = streamReader.ReadLine();
            }

            // Закрытие потока
            streamReader.Close();
        }

        // Метод для записи данных о студентах в файл
        public void writeStudentsInfo(University university)
        {
            // Объявление строки для записи
            string result = "";

            // Добавление в строку информации о всех студентах
            foreach (Student student in university.Students)
            {
                result += $"[index = {university.Students.IndexOf(student)}] {student.Name} {student.Surname}, возраст: {student.Age}, средний балл: {student.AverageScore}\n";
            }

            // Запись строки в файл
            StreamWriter streamWriter = new StreamWriter(Filename);
            streamWriter.WriteLine(result);
            streamWriter.Close();
        }
    }
}

// Основной класс программы
internal class Program
{
    static void Main(string[] args)
    {
        // Тестируем программу, создаем несколько студентов (объектов класса Student)
        Student student1 = new Student("Ivanov", "Ivan", 19, 4.2);
        Student student2 = new Student("Petrov", "Petr", 20, 3.5);
        Student student3 = new Student("Smirnov", "Gleb", 21, 4.99);

        // Создание класса университета, добавляем первого студента
        University university = new University(new List<Student> { student1 });

        // Проверяем работу поиска (метода FindStudent класса University)
        university.FindStudent("Smirnov", "Gleb");
        university.FindStudent("Ivanov", "Ivan");
        university.FindStudent("Petrov", "Petr");

        // Добавляем еще 2-х студентов
        university.AddStudent(student2);
        university.AddStudent(student3);

        // Снова проверяем поиск
        university.FindStudent("Smirnov", "Gleb");
        university.FindStudent("Ivanov", "Ivan");
        university.FindStudent("Petrov", "Petr");

        // Проверяем удаление студента
        university.RemoveStudent(student1);
        university.FindStudent("Ivanov", "Ivan");

        // Сохраняем данные в файл и считываем его
        DataAccess.StudentsRepository studentsRepository = new DataAccess.StudentsRepository("studentsRepository.txt");
        studentsRepository.writeStudentsInfo(university);
        studentsRepository.readStudentsInfo();
    }
}
